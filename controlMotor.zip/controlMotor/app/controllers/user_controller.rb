class UserController < ApplicationController
  def index
    # Código para manejar la acción index
  end
end
